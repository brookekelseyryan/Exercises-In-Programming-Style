# README

## Part X: Neural Networks

from *Exercises in Programming Style*:

- **35.3**: Implement a NN that transforms characters into their LEET counterparts.  Use any encoding and any LEET alphabet.
- **36.4**: Implement a NN that learns to transform characters into their LEET counterparts.  Use any encoding and any LEET alphabet. 
- **40.2**: Change the example program so that it also eliminates 2-letter words.



## Dependencies:

Ensure that your system has the following dependencies before running the programs.  For additional help or installation guides, follow the link to its official page.

### Python

[64-bit Python 3.8.6](https://www.python.org/downloads/release/python-386/)

### Libraries

[Keras 2.4.3](https://pypi.org/project/Keras/)

[Tensorflow 2.3.1](https://pypi.org/project/tensorflow/)

[Numpy 1.18.5](https://pypi.org/project/numpy/1.18.5/)

### Terminal 

[Git Bash terminal](https://git-scm.com/downloads) 



## To Run from the Command Line:

Starting in the folder from which you downloaded the .zip file, unzip its contents*

```
unzip BrookeRyan_Week9.zip -d BrookeRyan_Week9
```

Navigate to the Week9 directory:

```
cd BrookeRyan_Week9
```

### 35.py

```
python 35.py pride-and-prejudice.txt
```

### 36.py

```
python 36.py pride-and-prejudice.txt
```

### 40.py

```
python 40.py pride-and-prejudice.txt
```

### Notes

*Some systems may not come pre-installed with the unzip command.  Another option is to navigate to the folder in the file explorer, and right click on the icon to extract contents.*  

*On some systems, `python` should be replaced with `python3`.*

*The output of the files is quite long.  If you wish to terminate the program prematurely, use **Ctrl+C**.* 



## Troubleshooting

Ensure that you are running the program with a Python version between 3.5 and 3.8.  

Also ensure that your PATH variable points to the correct version of Python.  

Guide to installing libraries on Mac OS: https://piazza.com/class/kfl7e412uvcdn?cid=81_f1 



## Contact

**Author**: Brooke Ryan 

**Email**: brooke.ryan@uci.edu